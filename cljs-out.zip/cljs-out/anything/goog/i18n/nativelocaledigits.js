/*TRANSPILED*/goog.loadModule(function(exports) {'use strict';/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';
goog.module("goog.i18n.NativeLocaleDigits");
let LocaleScriptMap;
exports.LocaleScriptMap;
exports.FormatWithLocaleDigits = {"ar":"latn", "ar-EG":"arab", "bn":"beng", "fa":"arabext", "mr":"deva", "my":"mymr", "ne":"deva"};

;return exports;});
