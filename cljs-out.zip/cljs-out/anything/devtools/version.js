// Compiled by ClojureScript 1.11.60 {:optimizations :none}
goog.provide('devtools.version');
goog.require('cljs.core');
devtools.version.current_version = "1.0.5";
devtools.version.get_current_version = (function devtools$version$get_current_version(){
return devtools.version.current_version;
});

//# sourceMappingURL=version.js.map
