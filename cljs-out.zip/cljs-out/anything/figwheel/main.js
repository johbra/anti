// Compiled by ClojureScript 1.11.60 {:optimizations :none}
goog.provide('figwheel.main');
goog.require('cljs.core');

//# sourceMappingURL=main.js.map
