// Compiled by ClojureScript 1.11.60 {:optimizations :none}
goog.provide('process.env');
goog.require('cljs.core');

/**
 * @define {string}
 */
process.env.NODE_ENV = goog.define("process.env.NODE_ENV","development");

//# sourceMappingURL=env.js.map
